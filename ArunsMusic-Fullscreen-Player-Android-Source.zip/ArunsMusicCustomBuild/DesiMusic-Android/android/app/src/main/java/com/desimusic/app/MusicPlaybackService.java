package com.desimusic.app;

import android.content.Intent;
import android.net.Uri;
import androidx.annotation.Nullable;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.session.MediaSession;
import androidx.media3.session.MediaSessionService;

public class MusicPlaybackService extends MediaSessionService {
    public static final String ACTION_PLAY = "com.desimusic.app.PLAY";
    public static final String ACTION_PAUSE = "com.desimusic.app.PAUSE";
    public static final String ACTION_RESUME = "com.desimusic.app.RESUME";
    public static final String ACTION_STOP = "com.desimusic.app.STOP";

    private ExoPlayer player;
    private MediaSession mediaSession;

    @Override
    public void onCreate() {
        super.onCreate();
        player = new ExoPlayer.Builder(this).build();
        mediaSession = new MediaSession.Builder(this, player).build();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            String action = intent.getAction();
            if (ACTION_PLAY.equals(action)) {
                String url = intent.getStringExtra("url");
                String title = intent.getStringExtra("title");
                String artist = intent.getStringExtra("artist");
                String artwork = intent.getStringExtra("artwork");
                if (url != null && !url.isEmpty()) {
                    MediaMetadata.Builder metadata = new MediaMetadata.Builder()
                        .setTitle(title == null ? "Arun's Music" : title)
                        .setArtist(artist == null ? "Unknown artist" : artist);
                    if (artwork != null && !artwork.isEmpty()) {
                        metadata.setArtworkUri(Uri.parse(artwork));
                    }
                    MediaItem item = new MediaItem.Builder()
                        .setUri(Uri.parse(url))
                        .setMediaMetadata(metadata.build())
                        .build();
                    player.setMediaItem(item);
                    player.prepare();
                    player.play();
                }
            } else if (ACTION_PAUSE.equals(action)) {
                player.pause();
            } else if (ACTION_RESUME.equals(action)) {
                player.play();
            } else if (ACTION_STOP.equals(action)) {
                player.stop();
                stopSelf();
            }
        }
        return super.onStartCommand(intent, flags, startId);
    }

    @Nullable
    @Override
    public MediaSession onGetSession(MediaSession.ControllerInfo controllerInfo) {
        return mediaSession;
    }

    @Override
    public void onDestroy() {
        if (mediaSession != null) {
            mediaSession.release();
            mediaSession = null;
        }
        if (player != null) {
            player.release();
            player = null;
        }
        super.onDestroy();
    }
}
