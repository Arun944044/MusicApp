package com.desimusic.app;

import android.content.Intent;
import android.os.Build;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "MusicPlaybackPlugin")
public class MusicPlaybackPlugin extends Plugin {

    @PluginMethod
    public void play(PluginCall call) {
        String url = call.getString("url");
        if (url == null || url.trim().isEmpty()) {
            call.reject("A valid stream URL is required");
            return;
        }
        Intent intent = new Intent(getContext(), MusicPlaybackService.class);
        intent.setAction(MusicPlaybackService.ACTION_PLAY);
        intent.putExtra("url", url);
        intent.putExtra("title", call.getString("title", "Arun's Music"));
        intent.putExtra("artist", call.getString("artist", "Unknown artist"));
        intent.putExtra("artwork", call.getString("artwork", ""));
        startServiceCompat(intent);
        call.resolve(new JSObject().put("started", true));
    }

    @PluginMethod
    public void pause(PluginCall call) {
        send(MusicPlaybackService.ACTION_PAUSE);
        call.resolve();
    }

    @PluginMethod
    public void resume(PluginCall call) {
        send(MusicPlaybackService.ACTION_RESUME);
        call.resolve();
    }

    @PluginMethod
    public void stop(PluginCall call) {
        send(MusicPlaybackService.ACTION_STOP);
        call.resolve();
    }

    private void send(String action) {
        Intent intent = new Intent(getContext(), MusicPlaybackService.class);
        intent.setAction(action);
        startServiceCompat(intent);
    }

    private void startServiceCompat(Intent intent) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getContext().startForegroundService(intent);
        } else {
            getContext().startService(intent);
        }
    }
}
