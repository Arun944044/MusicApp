# Arun's Music Android

A Capacitor Android app that reuses the dynamic Arun's Music web player and adds native background audio playback using AndroidX Media3 (ExoPlayer + MediaSessionService).

## Requirements

- Node.js 18+
- Android Studio (current stable)
- Android SDK Platform 35 and Build Tools
- JDK 17
- Android device or emulator

## Build and run

From this folder:

```bash
npm install
npx cap sync android
```

Install Gradle 8.9 if it is not already available, then create the Gradle wrapper once:

```bash
cd android
gradle wrapper --gradle-version 8.9
```

Now open the `android` folder in Android Studio, allow Gradle sync, select a device, and press **Run**.

To build a debug APK from a terminal:

```bash
cd android
./gradlew assembleDebug
```

APK output:

`android/app/build/outputs/apk/debug/app-debug.apk`

## Background playback

The web UI calls the custom Capacitor plugin `MusicPlaybackPlugin` on Android. The plugin starts `MusicPlaybackService`, which uses Media3 ExoPlayer and MediaSessionService. This is the native playback path intended to continue audio after the app is backgrounded or the screen is locked, and it exposes Android media-session/notification controls.

The browser preview continues to use the HTML audio element.

## Music catalogues and limitations

- JioSaavn integration uses a community/unofficial public API endpoint and is not an official JioSaavn developer API. It can change, rate-limit, or stop working.
- Audius is an independent/community music catalogue, not a complete Indian film music catalogue.
- Search results and stream URLs are subject to each provider's terms, rights, regional restrictions, and availability.
- No API key is configured in this starter project. A provider may change its access requirements at any time.
- The app does not bundle copyrighted music files.

## Notes before release

1. Test playback with the specific provider stream URLs on a physical Android device.
2. On Android 13+, grant notification permission if prompted by the app/OS so media controls are visible in the notification shade.
3. Add a proper app icon, privacy policy, provider attribution/terms review, and release signing key before Play Store distribution.
4. The current UI's seek bar is hidden in native mode; play/pause and track navigation remain in the app UI, while Android's media notification provides system playback controls.


## APK build in GitHub Actions

The included `.github/workflows/android-apk.yml` workflow builds a debug APK when you push the project to a GitHub repository's `main` branch, or when you manually run the workflow. Download the `desi-music-debug-apk` artifact from the workflow run.
